# Define the list
zoo = ['lion', 'tiger', 'bear']

# Append 'elephant' to the list
zoo.append('elephant')

# Print the updated list
print(zoo)
