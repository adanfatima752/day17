# Define the list
fruits = ['apple', 'banana', 'cherry']

# Remove 'banana' from the list
fruits.remove('banana')

# Print the updated list
print(fruits)
