# Define the list
numbers = [10, 20, 30, 40, 50]

# Print the second element (index 1) and fourth element (index 3)
print("Second element:", numbers[1])
print("Fourth element:", numbers[3])
