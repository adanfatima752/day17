# Define the list
fruits = ['apple', 'banana', 'cherry']

# Insert 'grape' between 'apple' and 'banana'
fruits.insert(1, 'grape')

# Print the updated list
print(fruits)
