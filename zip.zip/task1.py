# Create a list named fruits with the specified elements
fruits = ['apple', 'banana', 'cherry']

# Print the list
print(fruits)
