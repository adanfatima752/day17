# Define the list
colors = ['red', 'green', 'blue', 'yellow', 'purple']

# Slice the list to get the first three elements
first_three_colors = colors[:3]

# Print the sliced list
print(first_three_colors)
