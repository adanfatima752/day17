# Define the list
languages = ['Python', 'Java', 'C++', 'JavaScript']

# Find the length of the list
length_of_list = len(languages)

# Print the length
print("The length of the list is:", length_of_list)
