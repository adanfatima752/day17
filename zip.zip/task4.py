# Define the list
animals = ['cat', 'dog', 'rabbit']

# Change the value of the third element (index 2)
animals[2] = 'hamster'

# Print the modified list
print(animals)
