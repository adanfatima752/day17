# Define the lists
list1 = [1, 2, 3]
list2 = [4, 5, 6]

# Concatenate the lists
concatenated_list = list1 + list2

# Print the concatenated list
print(concatenated_list)
