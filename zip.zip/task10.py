# Define the list
numbers = [1, 2, 3, 4, 5]

# Create a new list with the squares of all elements in the list
squared_numbers = [x**2 for x in numbers]

# Print the new list
print(squared_numbers)
